const Telegraf = require('telegraf') 
require('dotenv').config() 
const { updateData } = require('./JS/updateData.js')
const { textHandler } = require('./JS/textHandler.js')

const bot = new Telegraf( process.env.BOT_TOKEN ) 

    bot.command('update', async ctx => {
        ctx.reply ('UPDATE DATA');
        let res = await updateData();
        ctx.reply(JSON.stringify(res.data[0,1,2], null, 4))
    })

    textHandler(bot)





bot.launch()
