const rp = require('request-promise');
const s3 =  require('./s3.js')

const requestOptions = () => {
    return{
  method: 'GET',
  uri : 'https://pro-api.coinmarketcap.com/v1/cryptocurrency/listings/latest',
  qs : {
    'start': '1',
    'limit':'500',
    'convert': 'USD'
  },
  headers: {
    'X-CMC_PRO_API_KEY':  Aprocess.env.API_KEY
  },

  json : true,
  gzip : true
  }
};


module.exports.getData= async ()=> { //to recieve from api and to export data into index the JSF file
    try{
        let response = await rp(requestOptions());
        await writeS3(response)
        return response 
    }
    catch(err){
        console.log("API ERROR",err.message)  
    }
  

}