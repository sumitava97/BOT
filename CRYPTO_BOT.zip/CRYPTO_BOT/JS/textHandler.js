const { updateData } = require('./updateData.js')

module.exports.textHandler =  bot =>
{
    bot.on('text', async ctx => {
        let data = await updateData()

        let msg =  ctx.message.text
        let name = msg.charAt(0).toUpperCase() + msg.slice(1) //Bitcoin
        let symbol = msg.toUpperCase() //bitcoin
        let slug = msg.toLowerCase() //BTC
        let queryFound;

        data.data.forEach(element => {
            if (element.name == msg ||
                 element.symbol ==  msg || 
                 element.slug == msg
            ){
                queryFound =  true;
                ctx.replyWithHTML(onSuccess(element))
            }
 
        });
        if(!queryFound){
            ctx.reply('Cant find data \nSee /help');
        }
    });
};


const onSuccess =  element => {
    let logo = 'https://s2.coinmarketcap.com/static/img/coins/64x64/${element.id}.png';//URL image
    return '<b>${element.name} (${element.symbol})</b>'
    return '<b>Price: ${element.quote.USD.price}$ </b>'
    return '<b>Change 24h : ${element.USD.percent_change_24h}% </b>'
    return '<b>Market cap:  ${element.USD.market_cap}$ </b>'
    return '<a href = "${logo}"> & #160 </a>'
};
