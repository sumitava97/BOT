// for read and writing amazon functions
const AWS = require('aws-sdk')

AWS.config.update({
    accessKeyId: process.env.AWS_KEY,
    secretAccessKey: process.env.AWS_SECRET
})

const s3 =  new AWS.S3();

//READ S3
module.exports.readS3 =  async () => {
    console.log('S3: Read File')

    
let params ={
    Bucket: 'myfirstcryptobot',
    Key: 'data.json'
}

    return await new Promise((resolve,reject) => {
        s3.getObject(params,(error,data) => {
            if(error){
                console.log('S3: READ ERROR:${error.stack}')
                resolve({
                    statusCode:400,
                    error: 'S3: READ ERROR:${error.stack}'
                })
            }
            else {
                console.log('S3: SUCCESSFUL')
                resolve({
                    statusCode:200,
                    data: data
                })
            }
            
        })
    })
}

//write s3

module.exports.writeS3 =  async (input) => {
    console.log('S3: Write File')
    let dataBuff = Buffer.from(JSON.stringify(input,null,4))
    
let params ={
    Bucket: 'myfirstcryptobot',
    Key: 'data.json',
    Body: dataBuff
}

    return await new Promise((resolve,reject) => {

        s3.upload(params,(error,data) => {
            if(error){
                console.log('S3: WRITE ERROR:${error.stack}')
                resolve({
                    statusCode:400,
                    error: 'S3: WRITE ERROR:${error.stack}'
                })
            }
            else {
                console.log('S3: SUCCESSFUL')
                resolve({
                    statusCode:200,
                    data: data
                })
            }
            
        })
    })
}