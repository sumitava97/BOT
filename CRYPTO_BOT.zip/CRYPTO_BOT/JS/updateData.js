const { getData } = require('./getData.js')
const { readS3 } = require('./s3.js')

module.exports.updateData = async() =>

{
    //checking data.json in amazon s3 bucket
    //if data expired eg more than 15 min

    console.log('DATA CHECKING UPDATES....')
    let data = await readS3();
    data =  JSON.parse(data.data.Body.toString());
    const now = new Date()

    if(data){
        //if data.json exits
        let dataTimestamp =  new Date(data.status.timestamp)
        let deltaTime = (now-dataTimestamp) / 6000;

        if (deltaTime > process.env.maxDeltaTime){
            console.log('UPDATE DATA...')
            return await getData()
        }
        return data

    }else{
        // create data.json
        return await getData()
    }
}