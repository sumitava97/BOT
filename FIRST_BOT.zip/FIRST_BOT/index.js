require('dotenv').config() 
const Telegraf = require('telegraf') 
require('dotenv').config() 
const Extra = require('telegraf/extra')
const Markup =require('telegraf/markup')

const bot = new Telegraf(process.env.BOT_TOKEN)

bot.use(Telegraf.log())

//extra parameters
bot.hears('markdown',ctx => ctx.reply('*bold.text*',Extra.markdown()))
/*
//markup
bot.command('custom', ctx=> ctx.reply('Keyboard',Markup.keyboard(
    [['BUTTON','BUTTON1','BUTTON2'], //row 1
    ['PARIS','HEY','HOLA']] //row 2
)
.resize()
.extra()
))

bot.hears('BUTTON',ctx => ctx.reply('<a href = "https://loremflickr.com/g/320/240/paris/?lock=10 ">IMAGE URL </a>',Extra.HTML()))
const random = tag =>{
    let imgId = Math.trunc(Math.random()*1000)
    let url = 'https://loremflickr.com/g/320/240/${tag}/?lock${imgId}'
}

//inline keyboards

bot.command('inline', ctx=> ctx.reply('<a href = "https://loremflickr.com/g/320/240/paris"></a>',
Extra.HTML().markup( (m)=> m.inlineKeyboard( [ m.callbackButton('NEXT IMAGE','paris'),m.callbackButton('Dog','dog') ] ))
))

// /bot.action('paris', ctx=> ctx.editMessageText('text',markup)) // for next image

bot.action('paris', ctx=> ctx.editMessageText('<a href = "https://loremflickr.com/g/320/240/dog"></a>',
Extra.HTML()
))

*/
bot.launch() 
